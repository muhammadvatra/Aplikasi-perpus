<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <a href="#">Made in</a>
            <a href="#">By</a>
            <a href="#">Vatra</a>
            <a href="#">(221240001278)</a>
            <a href="#">DB</a>
        </div>
    </div>
</div>
